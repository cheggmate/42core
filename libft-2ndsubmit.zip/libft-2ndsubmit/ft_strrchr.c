/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strrchr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jotong <jotong@student.42singapore.sg>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/05 23:27:29 by jotong            #+#    #+#             */
/*   Updated: 2025/05/21 01:20:10 by jotong           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>

char	*ft_strrchr(const char *str, int c)
{
	unsigned char	*ptr;
	unsigned char	*latest;

	ptr = (unsigned char *)str;
	latest = NULL;
	while (*ptr)
	{
		if (*ptr == (unsigned char)c)
			latest = ptr;
		ptr++;
	}
	if (c == '\0')
		return ((char *)ptr);
	else
		return ((char *)latest);
}
