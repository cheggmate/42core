/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_flow.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jotong <jotong@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/19 21:06:30 by jotong            #+#    #+#             */
/*   Updated: 2025/06/20 17:59:58 by jotong           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_push_swap.h"

static void	sort_a_logic(int **stacks, int *len, int *sml_bg, int *counts)
{
	if (stacks[0][0] < sml_bg[0])
	{
		// printf("smallest stack\n");
		pushb(stacks[1], stacks[0], len);
		rotate(stacks[1], len, 'b');
		counts[0]++;
	}
	else if (stacks[0][0] <= sml_bg[1])
	{
		// printf("middle stack\n");
		pushb(stacks[1], stacks[0], len);
		counts[1]++;
	}
	else
	{
		// printf("largest stack\n");
		rotate(stacks[0], len, 'a');
		counts[2]++;
	}
}

void	ft_sort_a(int **stacks, int *len, int *sml_bg, int n, int iter)
{
	int i;
	int	counts[3];

	iter++;
	printf("iter = %d\n", iter);
	i = -1;
	if (n <= 3)
	{
		printf("sort a\n");
		sort_stack(stacks[0], stacks[1], len);
	}
	else
	{
		// printf("sort a(n>3)\n");				// remove before submission
		// print_stack(stacks[0], len, 'a');
		find_mids(stacks[0], len[0], sml_bg);
		printf("sort a: sml_bg[0] = %d, sml_bg[1] = %d\n", sml_bg[0], sml_bg[1]);
		counts[0] = 0;
		counts[1] = 0;
		counts[2] = 0;
		while (i++ < n)
		{
			sort_a_logic(stacks, len, sml_bg, counts);
			// print_stack(stacks[0], len, 'a');
		}
			
		// printf("after sorting a logic\n");
		// print_stack(stacks[0], len, 'a');
		while (counts[2]--)
			rev_rot(stacks[0], len, 'a');
		ft_sort_b(stacks, len ,sml_bg, counts[1], iter);
		printf("n = %d, counts[0] = %d, counts[1] = %d, counts[2] = %d\n", n, counts[0], counts[1], counts[2]);
		ft_sort_a(stacks, len, sml_bg, n - counts[1] - counts[2], iter);
		while (counts[0]--)
			rev_rot(stacks[1], len, 'b');
		ft_sort_b(stacks, len, sml_bg, counts[0], iter);
	}
}

static void	sort_b_logic(int **stacks, int *len, int *sml_bg, int *counts)
{
	if (stacks[1][0] > sml_bg[1])
	{
		// largest
		pusha(stacks[0], stacks[1], len);
		counts[2]++;
	}
	else if (stacks[1][0] < sml_bg[0])
	{
		// middle
		pusha(stacks[0], stacks[1], len);
		rotate(stacks[0], len, 'a');
		counts[1]++;
	}
	else
	{
		// smallest
		rotate(stacks[1], len, 'b');
		counts[0]++;
	}
}

void	ft_sort_b(int **stacks, int *len, int *sml_bg, int n, int iter)
{
	int i;
	int	counts[3];

	iter++;
	printf("iter = %d\n", iter);
	i = -1;
	if (n <= 3)
	{
		printf("sort b\n");
		// printf("n = %d\n", n);
		// print_stack(stacks[1], len, 'b');
		sort_stack(stacks[1], stacks[0], len);
	}
	else
	{
		find_mids(stacks[1], len[1], sml_bg);
		printf("sort b: sml_bg[0] = %d, sml_bg[1] = %d\n", sml_bg[0], sml_bg[1]);
		counts[0] = 0;
		counts[1] = 0;
		counts[2] = 0;
		while (i++ < n)
			sort_b_logic(stacks, len, sml_bg, counts);
		printf("after sorting b logic\n");
		print_stack(stacks[0], len, 'a');
		print_stack(stacks[1], len, 'b');
		printf("counts[0] = %d, counts[1] = %d, counts[2] = %d\n", counts[0], counts[1], counts[2]);
		while (counts[1]--)
			rev_rot(stacks[0], len, 'a');
		ft_sort_a(stacks, len, sml_bg, counts[0] + counts[1], iter);
		ft_sort_b(stacks, len, sml_bg, counts[0], iter);
		// while (counts[0]--)
		// 	rev_rot(stacks[1], len, 'b');
	}
}
